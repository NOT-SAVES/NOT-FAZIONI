----------- ESEMPIO FAZIONE  ---------

TriggerEvent('gridsystem:registerMarker', {
    name = 'inventario_tutti',
    pos = vector3(1399.8713, 1139.6736, 114.3356),
    size = vector3(0.8, 0.8, 0.8),
    scale = vector3(0.7, 0.7, 0.7),
    type = 9,
    control = 'E',
    rotate = 0.0,
    rotate2 = 0.0,
    shouldBob = false,
    shouldRotate = true,
    color = { r = 255, g = 255, b = 255 },
    trasparent = 255,
    customt = 'marker',
    msg = 'Apri inventario',
    msg2 = '',
    action = function()
        exports.ox_inventory:openInventory('stash', {id='police'})
    end
  })

  TriggerEvent('gridsystem:registerMarker', {
    name = 'boss722',
    pos = vector3(1392.0227, 1147.5026, 114.3357),
    size = vector3(0.8, 0.8, 0.8),
    scale = vector3(0.7, 0.7, 0.7),
    type = 9,
    control = 'E',
    rotate = 0.0,
    rotate2 = 0.0,
    shouldBob = false,
    shouldRotate = true,
    color = { r = 255, g = 255, b = 255 },
    trasparent = 255,
    customt = 'marker',
    msg = 'Apri inventario',
    msg2 = '',
    action = function()
      exports['Ricky-BossMenu']:OpenBossMenu('police') -- ONLY CLIENT SIDE
    end
  })


  TriggerEvent('gridsystem:registerMarker', {
    name = 'boss_inv_722',
    pos = vector3(1401.4008, 1132.2902, 114.3357),
    size = vector3(0.8, 0.8, 0.8),
    scale = vector3(0.7, 0.7, 0.7),
    type = 9,
    control = 'E',
    rotate = 0.0,
    rotate2 = 0.0,
    shouldBob = false,
    shouldRotate = true,
    color = { r = 255, g = 255, b = 255 },
    trasparent = 255,
    customt = 'marker',
    msg = 'Deposito Boss',
    msg2 = '',
    action = function()
      if ESX.GetPlayerData().job.grade_name == 'boss' and ESX.GetPlayerData().job.name == 'police' then
        exports.ox_inventory:openInventory('stash', {id='police'})
    else
        ESX.ShowNotification('Questo inventario è solo per il capo')
    end
  end
})

for k, v in pairs(FAZIONE) do 
  local point = lib.points.new({
      coords = v.garage.pos,
      distance = 3,
  })

  function point:onEnter()
      lib.showTextUI('[E] - Open Garage')
  end

  function point:onExit()
      lib.hideTextUI()
  end

  function point:nearby()
    if not HasStreamedTextureDictLoaded("marker") then
        RequestStreamedTextureDict("marker", true)
        while not HasStreamedTextureDictLoaded("marker") do
            Wait(1)
        end
    else
        -- Marker
        DrawMarker(9, 1413.4315, 1115.1162, 114.8337, 0.20, 0.20, 0.0, 90.0, 90.0, 90.0, 1.0, 1.0, 1.0, 255, 255, 255, 255,false, false, 2, true, "marker", "garage", false)
    end

      if self.currentDistance < 1 and IsControlJustReleased(0, 38) then
          local player = ESX.GetPlayerData()

          if player.job and player.job.name == k then 
              apriGarageFazioni(v.garage)
          else
              lib.notify({
                  id = 'some_identifier',
                  title = 'Access Denied',
                  description = 'NON PUOI APRIRE QUESTO GARAGE!',
                  position = 'top',
                  style = {
                      backgroundColor = '#141517',
                      color = '#C1C2C5',
                      ['.description'] = {
                          color = '#909296'
                      }
                  },
                  icon = 'fa-solid fa-exclamation-triangle', 
                  iconColor = '#F8F9FA'
              })
          end
      end
  end
end

function apriGarageFazioni(garage)

  local options = {}

  for k, v in pairs(garage.car) do
  
      print(ESX.DumpTable(v))
      
      options[#options+1] = { 
          label = v.label,
          icon = 'fa-solid fa-car',
          args = {value = v.value}
      }
  end

  options[#options+1] = { 
      label = 'Deposita',
      icon = 'fa-solid fa-warehouse',  
      args = {deposita = true}
  }


  lib.registerMenu({
      id = 'garageFazioni',
      title = garage.titleMenu,
      position = garage.posMenu,
      options = options
  }, function(selected, scrollIndex, args)
     
      if args.deposita then local vehicle = cache.vehicle or GetVehiclePedIsIn(cache.ped, false)
          DeleteEntity(vehicle)
      else
          local model = lib.requestModel(args.value) 
          if not model then return end
  
          local vehicle = CreateVehicle(model, garage.pos, true, false)
          SetVehicleCustomPrimaryColour(vehicle, garage.primaryColor[1], garage.primaryColor[2], garage.primaryColor[3])
          SetVehicleCustomSecondaryColour(vehicle, garage.secondaryColor[1], garage.secondaryColor[2], garage.secondaryColor[3])        
          SetVehicleFuelLevel(vehicle, 100.0)
          SetEntityHeading(vehicle, garage.heading)
          SetVehicleNumberPlateText(vehicle, garage.plate)
          SetModelAsNoLongerNeeded(model)
          NetworkFadeInEntity(vehicle, 1)
          SetPedIntoVehicle(cache.ped, vehicle, -1)
      end
  end)
  
  lib.showMenu('garageFazioni')
end