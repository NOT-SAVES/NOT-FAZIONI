FAZIONE = {

    police = {              --- nome del job ---
        garage = {
            titleMenu = 'Garage', -- Garage menu title
            posMenu = 'top-right', -- Garage menu position
            pos = vector3(1413.4315, 1115.1162, 114.8337), -- Garage position
            spawnPoint = vector3(1402.8608, 1118.1764, 114.8367), -- Spawn point position
            heading = 310.8244, -- Heading angle
            plate = 'NOME FAZIONE', -- Plate name
            primaryColor = {173, 16, 241}, -- Primary color 
            secondaryColor = {173, 16, 241}, -- Secondary color
            car = {
                { label = 'Faction', value = 'faction' }, -- Car options (label, value)
                { label = 'Brioso', value = 'brioso' },
                { label = 'T20', value = 't20' },
            }
        }
    }


}